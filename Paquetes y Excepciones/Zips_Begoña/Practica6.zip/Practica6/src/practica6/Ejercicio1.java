package practica6;

import java.util.Scanner;

public class Ejercicio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method 
		char letra,primera;
		int cont=1,contP=1;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Introduce una letra:");
		letra=sc.nextLine().charAt(0);
		primera=letra;
		
		while(cont!=10) {
			System.out.println("Introduce una letra:");
			letra=sc.nextLine().charAt(0);
			if (letra==primera)
				contP++;
			cont++;
		}
		
		System.out.println("La letra "+primera+" ha aparecido "+contP+" veces");
		
		

	}

}
