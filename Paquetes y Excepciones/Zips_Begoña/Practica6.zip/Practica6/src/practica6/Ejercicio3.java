package practica6;

import java.util.Locale;
import java.util.Scanner;

public class Ejercicio3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double calibre;
		int contA=0,contB=0,contC=0;
		Scanner sc=new Scanner(System.in);
		sc.useLocale(Locale.ENGLISH);
		
		System.out.println("Introduce calibre fresa:");
		calibre=sc.nextDouble();
		
		while(calibre!=0) {
			if (calibre>=1 && calibre<3)
				contA++;
			else
				if (calibre>=3 && calibre<=5)
					contB++;
				else
					if (calibre>5)
						contC++;
					else
						System.out.println("Calibre no pertenece a ninguna categoría");
			
			System.out.println("Introduce calibre fresa:");
			calibre=sc.nextDouble();
				
		}
		System.out.println("Categoria A:"+contA+",categoria B:"+contB+",categoria C:"+contC);
		if (contA==0 || contB==0 || contC==0)
			System.out.println("No ha habido fresas de todas las categorias");
		else // contA!=0 && contB!=0 && contC!=0
			System.out.println("Ha habido fresas de todas las categorias");
		
		

	}

}
