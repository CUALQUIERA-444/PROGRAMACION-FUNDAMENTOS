package practica6;

import java.util.Scanner;

/*
 * Calcular el precio de la entrada a un parque de atracciones teniendo en cuenta lo siguiente:
Hay dos tarifas, reducida 16 euros (para menores de 7 años y mayores de 65) y normal 25
euros (para el resto). Todos los mayores de 18 años pueden sacar además ticket para ver la
actuación de un grupo de teatro con un coste adicional de 3 euros.
Para realizar el programa mostrar un menú con las opciones
 Comprar entrada: leer la edad de la persona y en el caso de que sea mayor de
edad preguntar si desea ver el teatro
 Cerrar taquilla:se muestra el importe total recaudado y se acaba el programa
 */
public class ejercicio6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int opc, edad;
		double precio, recaudación = 0;
		Scanner sc = new Scanner(System.in);

		do {
			System.out.println("Anota una opción:");
			System.out.println("1. Comprar entrada");
			System.out.println("2. Cerrar taquilla");
			opc = sc.nextInt();
			switch (opc) {
			case 1:
				System.out.println("Anota la edad:");
				edad = sc.nextInt();
				if (edad < 7 || edad > 65)
					precio = 16;
				else {
					precio = 25;
				}
				if (edad >= 18) {
					System.out.println("Quiere ir al teatro?");
					boolean teatro = sc.nextBoolean();
					if (teatro)
						precio += 3;
				}

				System.out.println("Tiene que pagar:" + precio + " euros");
				recaudación += precio;
				break;
			case 2:
				System.out.println("Taquilla cerrada. ");
				System.out.println("Se han recaudado:" + recaudación + " euros");
				break;
			default:
				System.out.println("Opción incorrecta");
			}

		} while (opc != 2);

	}

}
