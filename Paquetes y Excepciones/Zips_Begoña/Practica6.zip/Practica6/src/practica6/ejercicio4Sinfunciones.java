package practica6;

import java.util.Scanner;

/*
 * Hacer un programa en el que se simula la compra de entradas en el museo de la siguiente
forma:
Por cada grupo que llega se anota el número de adultos y el número de niños y si se aplica
tarifa reducida o no. Con esta información se calcula el importe total de las entradas de
cada grupo y se muestra por pantalla. El programa termina cuando se hayan recaudado
más de 100 euros.
Mostrar al final el número de entradas del grupo que más entradas ha comprado.
 */
public class ejercicio4Sinfunciones {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double compra, totalRecaudado = 0, maximo = 0;
		int adultos, niños,totalentradas;
		boolean reducida;
		final double RAD=2,AD=3,RINF=1.2,INF=2;
		Scanner sc = new Scanner(System.in);

		do {
			System.out.println("Anota número de adultos:");
			adultos = sc.nextInt();
			System.out.println("Anota número de niños:");
			niños = sc.nextInt();
			System.out.println("Es tarifa reducida?");
			reducida = sc.nextBoolean();
			if (reducida)
				compra=adultos*RAD+niños*RINF;
			else
				compra=adultos*AD+niños*INF;
					
			totalentradas=adultos+niños;
			if (totalentradas > maximo)
				maximo = totalentradas;
			System.out.println("Tienes que pagar:" + compra);
			totalRecaudado += compra;
		} while (totalRecaudado <= 100);

		System.out.println("Total recaudado:" + totalRecaudado);
		System.out.println("El grupo que más entradas ha comprado, ha comprado un total de " + maximo + " entradas");
	}

	
}
