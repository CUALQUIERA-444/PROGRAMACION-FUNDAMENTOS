package practica6;
/*
 * En unos multicinesse están proyectando dos películas en dos salas distintas. Cada persona
que llega compra varias entradas para la misma película. Realizar un programa en el que se
anota por cada persona que llega a la taquilla el número de sala y el número de entradas
que compra para esa sala, el programa finaliza al anotar la sala 0. Mostrar el número total
de entradas vendidas y decir para que sala se han vendido más entradas. Decir además si
ha habido alguien que haya comprado más de 10 entradas.
 */
import java.util.Scanner;

public class ejercicio5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numSala,entradas,entradasS1=0,entradasS2=0;
		boolean masDeDiez=false;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Anota sala(0/1/2):");
		numSala=sc.nextInt();
		while(numSala!=0) {
			if (numSala!=1 && numSala!=2)
				System.out.println("Número de sala incorrecto:");
			else {
				System.out.println("Introduce número de entradas:");
				entradas=sc.nextInt();
				if (entradas>10)
					masDeDiez=true;
				if (numSala==1)
					entradasS1=entradas+entradasS1;
				else
					entradasS2=entradas+entradasS2;
			}
			System.out.println("Anota sala(0/1/2):");
			numSala=sc.nextInt();
		}
		
		if (masDeDiez)
			System.out.println("Al menos un usuario ha comprado más de 10 entradas");
		
		System.out.println("Total entradas vendidas:"+(entradasS1+entradasS2));
		if (entradasS1>entradasS2)
			System.out.println("Se han vendido más entradas para la sala1");
		else
			if (entradasS2>entradasS1)
				System.out.println("Se han vendido más entradas para la sala2");
			else
				System.out.println("Se han vendido el mismo número de entradas para las dos salas");

	}

}
