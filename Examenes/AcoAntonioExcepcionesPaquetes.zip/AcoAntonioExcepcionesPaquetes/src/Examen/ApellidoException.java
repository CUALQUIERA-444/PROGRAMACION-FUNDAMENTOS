package Examen;

public class ApellidoException extends Exception{

	public ApellidoException(String string) {
		// TODO Auto-generated constructor stub
	}

}
