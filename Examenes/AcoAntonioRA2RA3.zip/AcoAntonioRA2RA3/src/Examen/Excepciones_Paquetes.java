package Examen;
import java.util.InputMismatchException;
import java.util.Scanner;
public class Excepciones_Paquetes {
	static Scanner sc = new Scanner (System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//Contabilizar tiempo
	//Leer de teclado el codigo de empleado, que es un String de tamaño 6 o 7
	String codigo_empleado = "";
	String caracteres_val;
	String caracteres_val2;
	String regex = "0?[100-500]+"; 
	boolean validacion = false;
	boolean validacion2 = false;
	do {
		do {
		try {
		System.out.println("Introduce el código correspondiente (MKT, DES, RRH Y NUMERO DE EMPLEADO ENTRE 100 Y 500 (PUEDE USAR UN 0 DELANTE SI LO DESEA");
		codigo_empleado = sc.nextLine();
		if(codigo_empleado.length() != 6 && codigo_empleado.length() !=7 ) { 
			System.out.println("Lo siento longitud no valida");
			validacion2 = false;
		}
		validacion2 = true;
		}
		catch (InputMismatchException e) {
			sc.nextLine();
			System.out.println("No coinciden los numeros");
			validacion2 = false;
		}
		caracteres_val2 = codigo_empleado.substring(3,codigo_empleado.length()-1);
		caracteres_val2.matches(regex);
		}
		while (validacion2 == false);
		caracteres_val = codigo_empleado.substring(0,3);
		if (caracteres_val.equalsIgnoreCase("MKT") == false && caracteres_val.equalsIgnoreCase("DES") == false && caracteres_val.equalsIgnoreCase("RRH") == false) {
		System.out.println("Lo siento vuelva a intentarlo poniendo los parametros indicados");
		validacion = false;
		}
		else 
			validacion = true;
		}
	while (validacion == false);
	}
	}

